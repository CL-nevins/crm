##### 简要描述

- 获取管理员列表接口

##### 请求URL
- ` http://xxx.com/api/admin/list`
  
##### 请求方式
- POST

##### 参数

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|time |是  |int |请求时间戳(秒级)   |
|guid |业务型验证时为必传  |string | 用户唯一id(用户未登陆时使用默认约定值)    |
|param |是  |json | 所包含的所有业务参数    |
|--page |是  |int | 当前页    |
|--limit |是  |int | 每页条数    |
|--where |是  |json | 内含搜索参数    |
|----user_name |否  |int | 用户名搜索    |
|----nick_name |否  |int | 昵称搜索    |
|----phone |否  |int | 手机号    |
|----searchDate |否  |int | 时间区间搜索    |
|signatures |是  |string | 加密后的签名    |
|version |是  |int | 接口版本号    |

##### 返回示例 

``` 
{
    "code": 200,
    "data": {
        "data": [
            {
                "guid": "1a9dde8481c474be3b43c0ffb4ac7dbe",
                "admin_name": "test",
                "password": "e0498134cd63ebfd45ee25714453cc6d",
                "status": 1,
                "add_time": 1613186880,
                "nick_name": "张三",
                "avatar": "https://csdn-exam.oss-cn-shenzhen.aliyuncs.com/index.jpg"
            },
           {
                "guid": "1a9dde8481c474be3b43c0ffb4ac7dbe",
                "admin_name": "test",
                "password": "e0498134cd63ebfd45ee25714453cc6d",
                "status": 1,
                "add_time": 1613186880,
                "nick_name": "张三",
                "avatar": "https://csdn-exam.oss-cn-shenzhen.aliyuncs.com/index.jpg"
            }
        ],
        "count": 2
    },
 "message":"success"
}
```
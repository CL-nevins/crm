
##### 简要描述

- 添加客户接口

##### 请求URL
- ` http://xxx.com/api/customer/add `
  
##### 请求方式
- POST 

##### 参数

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|time |是  |int |请求时间戳(秒级)   |
|guid |是  |string | 用户唯一id   |
| param |是  |json | 所包含的所有业务参数    |
| --type |是  |int | 客户类别    |
| --customer_name |是  |string | 客户名称    |
| --name |是  |string | 联系人名称    |
| --phone |是  |string | 手机号    |
| --gender |是  |int | 性别    |
| --birthday |是  |int | 出生年月日    |
| --email |是  |int | 电子邮箱    |
| --city |是  |int | 省市区    |
| --address |是  |int | 详细地址    |
| signatures |是  |string | 加密后的签名    |
| version |是  |int | 接口版本号    |

##### 返回示例 

``` 
  {
    "message ":'添加成功'
	"code": 200,
	"data":""
  }
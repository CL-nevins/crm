##### 简要描述

- H5获取客户咨询列表接口

##### 请求URL
- ` http://xxx.com/h5/customer/link/list`

##### 请求方式
- POST

##### 参数

|参数名|必选|类型|说明|
|:----    |:---|:----- |-----   |
|time |是  |int |请求时间戳(秒级)   |
|guid |业务型验证时为必传  |string | 用户唯一id(用户未登陆时使用默认约定值)    |
|param |是  |json | 所包含的所有业务参数    |
|--customer_guid |是  |string | 客户唯一id    |
|--page |是  |int | 当前页    |
|--limit |是  |int | 每页条数    |
|--where |是  |json | 内含搜索参数    |
|----add_staff |否  |string | 操作人id    |
|----searchDate |否  |string | 时间区间搜索    |
|signatures |是  |string | 加密后的签名    |
|version |是  |int | 接口版本号    |

##### 返回示例 

``` 
{
    "code": 200,
    "data": {
        "data": [
            {
                "guid": "1a9dde8481c474be3b43c0ffb4ac7dbe",
                "type": 1,
                "customer_name": "xxxx公司",
                "name": "张三",
				"phone": 133445566789,
                "add_time": 1613186880
            },
            {
                "guid": "1a9dde8481c474be3b43c0ffb4ac7dbe",
                "type": 1,
                "customer_name": "xxxx公司",
                "name": "张三",
				"phone": 133445566789,
                "add_time": 1613186880
            }
        ],
        "count": 2
    },
 "message":"success"
}
```